import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import Razorpay from 'razorpay';
import { createClient } from '@supabase/supabase-js';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

const required = ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','RAZORPAY_KEY_ID',
  'RAZORPAY_KEY_SECRET','JWT_SECRET','ADMIN_PASSWORD_HASH'];
const missing = required.filter(k => !process.env[k] || process.env[k].includes('replace_me'));
if (missing.length) console.warn('Missing configuration:', missing.join(', '));

const supabase = process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY,
      { auth: { persistSession: false, autoRefreshToken: false } }) : null;
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb', verify: (req, _res, buf) => {
  if (req.originalUrl === '/api/payments/webhook') req.rawBody = Buffer.from(buf);
} }));
app.use(express.static(path.join(root, 'public')));

const packages = {
  followers: [
    { id:'f-start', name:'Starter discovery', amount:29900, description:'Profile discovery campaign planning' },
    { id:'f-creator', name:'Creator growth', amount:79900, description:'Audience and content campaign planning' },
    { id:'f-pro', name:'Pro reach', amount:149900, description:'Expanded profile promotion planning' }
  ],
  likes: [
    { id:'l-start', name:'Post starter', amount:24900, description:'Single-post promotion planning' },
    { id:'l-engage', name:'Engagement boost', amount:69900, description:'Multi-post promotion planning' },
    { id:'l-spotlight', name:'Content spotlight', amount:129900, description:'Broader content promotion planning' }
  ],
  views: [
    { id:'v-start', name:'Reel starter', amount:29900, description:'Single-video promotion planning' },
    { id:'v-reach', name:'Video reach', amount:79900, description:'Multi-video promotion planning' },
    { id:'v-spotlight', name:'Video spotlight', amount:149900, description:'Broader video awareness planning' }
  ]
};
const validServices = new Set(Object.keys(packages));
const safeText = (v, max=500) => typeof v === 'string' ? v.trim().slice(0,max) : '';
const isHttpUrl = value => {
  try { const u = new URL(value); return u.protocol === 'https:' || u.protocol === 'http:'; }
  catch { return false; }
};
function requireDb(req,res,next) {
  if (!supabase) return res.status(503).json({ error:'Database is not configured yet.' });
  next();
}
function requireAdmin(req,res,next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.role !== 'admin') throw new Error('wrong role');
    req.admin = payload; next();
  } catch { return res.status(401).json({error:'Please sign in as admin.'}); }
}

app.get('/api/health', (_req,res) => res.json({ok:true, service:'Boostly API'}));
app.get('/api/packages', (_req,res) => res.json(packages));

app.post('/api/admin/login', (req,res) => {
  const password = safeText(req.body?.password, 300);
  const hash = process.env.ADMIN_PASSWORD_HASH || '';
  if (!password || !hash.startsWith('$2')) return res.status(503).json({error:'Admin password hash is not configured.'});
  if (!bcrypt.compareSync(password, hash)) return res.status(401).json({error:'Invalid credentials.'});
  const token = jwt.sign({role:'admin'}, process.env.JWT_SECRET, {expiresIn:'8h'});
  res.json({token, expiresIn:28800});
});

app.post('/api/orders', requireDb, async (req,res) => {
  try {
    const customer_name = safeText(req.body?.customer_name,100);
    const contact = safeText(req.body?.contact,120);
    const service = safeText(req.body?.service,20);
    const packageId = safeText(req.body?.package_id,40);
    const target_url = safeText(req.body?.target_url,500);
    const target_username = safeText(req.body?.target_username,100);
    const audience_notes = safeText(req.body?.audience_notes,500);
    if (!customer_name || !contact || !validServices.has(service) || !isHttpUrl(target_url))
      return res.status(400).json({error:'Please provide valid order details and a profile/post URL.'});
    const chosen = packages[service].find(p => p.id === packageId);
    if (!chosen) return res.status(400).json({error:'Unknown package.'});
    if (!razorpay) return res.status(503).json({error:'Razorpay is not configured yet.'});

    const order = await razorpay.orders.create({
      amount: chosen.amount, currency:'INR',
      receipt: `boostly_${crypto.randomUUID().replaceAll('-','').slice(0,20)}`,
      notes: {service, package_id:chosen.id}
    });
    const {data, error} = await supabase.from('orders').insert({
      customer_name, contact, service, package_name:chosen.name,
      amount_paise:chosen.amount, target_url, target_username, audience_notes,
      razorpay_order_id:order.id, status:'pending_payment', payment_status:'created'
    }).select('id').single();
    if (error) throw error;
    res.status(201).json({
      order_id:data.id, razorpay_order_id:order.id, amount:chosen.amount,
      currency:'INR', key_id:process.env.RAZORPAY_KEY_ID,
      name:'Boostly', description:chosen.description
    });
  } catch (e) {
    console.error('Create order failed:', e.message);
    res.status(500).json({error:'Could not create order. Please try again later.'});
  }
});

app.post('/api/payments/verify', requireDb, async (req,res) => {
  try {
    const orderId = safeText(req.body?.razorpay_order_id,100);
    const paymentId = safeText(req.body?.razorpay_payment_id,100);
    const signature = safeText(req.body?.razorpay_signature,300);
    if (!orderId || !paymentId || !signature) return res.status(400).json({error:'Missing payment details.'});
    const expected = crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET)
      .update(`${orderId}|${paymentId}`).digest('hex');
    const a=Buffer.from(expected), b=Buffer.from(signature);
    if (a.length !== b.length || !crypto.timingSafeEqual(a,b))
      return res.status(400).json({error:'Payment signature verification failed.'});
    const {data:existing,error:lookupError} = await supabase.from('orders')
      .select('id,status').eq('razorpay_order_id',orderId).single();
    if (lookupError || !existing) return res.status(404).json({error:'Order not found.'});
    const {error} = await supabase.from('orders').update({
      razorpay_payment_id:paymentId,payment_status:'paid',status:'paid'
    }).eq('id',existing.id);
    if (error) throw error;
    res.json({ok:true, message:'Payment verified. Your order is recorded.'});
  } catch(e) {
    console.error('Payment verification failed:',e.message);
    res.status(500).json({error:'Could not verify payment.'});
  }
});

// Configure a Razorpay webhook at /api/payments/webhook and use the same secret
// in RAZORPAY_WEBHOOK_SECRET. This supports asynchronous payment events.
app.post('/api/payments/webhook', express.raw({type:'application/json'}), async (req,res) => {
  if (!supabase || !process.env.RAZORPAY_WEBHOOK_SECRET) return res.status(503).send('Not configured');
  const signature = req.headers['x-razorpay-signature'];
  const body = req.rawBody;
  if (!body) return res.status(400).send('Missing raw webhook body');
  const expected = crypto.createHmac('sha256',process.env.RAZORPAY_WEBHOOK_SECRET).update(body).digest('hex');
  if (!signature || signature.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return res.status(400).send('Invalid signature');
  try {
    const event = JSON.parse(body.toString('utf8'));
    if (event.event === 'payment.captured' || event.event === 'order.paid') {
      const entity = event.payload?.payment?.entity;
      const rOrderId = entity?.order_id || event.payload?.order?.entity?.id;
      const rPaymentId = entity?.id;
      if (rOrderId) await supabase.from('orders').update({
        payment_status:'paid',status:'paid',...(rPaymentId?{razorpay_payment_id:rPaymentId}:{})
      }).eq('razorpay_order_id',rOrderId);
    } else if (event.event === 'payment.failed') {
      const entity=event.payload?.payment?.entity;
      if(entity?.order_id) await supabase.from('orders').update({
        payment_status:'failed',status:'payment_failed'
      }).eq('razorpay_order_id',entity.order_id);
    }
    res.json({received:true});
  } catch(e) { console.error('Webhook processing failed:',e.message);res.status(500).send('Webhook error'); }
});

app.get('/api/admin/orders', requireDb, requireAdmin, async (req,res) => {
  const {data,error} = await supabase.from('orders').select('*').order('created_at',{ascending:false}).limit(300);
  if(error) return res.status(500).json({error:'Could not load orders.'});
  res.json({orders:data});
});
app.patch('/api/admin/orders/:id', requireDb, requireAdmin, async (req,res) => {
  const allowed = new Set(['processing','completed','cancelled','refunded']);
  const status = safeText(req.body?.status,30);
  const admin_note = safeText(req.body?.admin_note,1000);
  if (!allowed.has(status)) return res.status(400).json({error:'Invalid order status.'});
  const updates = {status,admin_note};
  if(status==='refunded') updates.payment_status='refunded';
  const {data,error} = await supabase.from('orders').update(updates).eq('id',req.params.id).select('id,status').single();
  if(error) return res.status(500).json({error:'Could not update order.'});
  res.json({order:data});
});

app.get('*', (req,res,next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(root,'public','index.html'));
});
app.listen(port,()=>console.log(`Boostly running on port ${port}`));
