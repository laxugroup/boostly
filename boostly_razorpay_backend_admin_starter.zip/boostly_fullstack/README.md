BOOSTLY FULL-STACK STARTER — Razorpay + Supabase + Admin API

WHAT'S INCLUDED
- Responsive purple storefront with Followers / Likes / Views package tabs.
- Express backend with package endpoint and order creation.
- Razorpay Checkout order creation on the server.
- Payment signature verification endpoint and optional webhook endpoint.
- Supabase Postgres schema for orders and payment states.
- Admin login endpoint (JWT), admin order-list API, order status update API, and a visual admin dashboard at /admin.html.
- This is a deployment starter, not an already deployed/live website. You must create accounts and configure secrets.

STACK
- Frontend + Node backend: one Express app (can deploy on Render free tier if currently available).
- Database: Supabase free tier if available for your account/region.
- Domain: the Render URL is enough to test; Netlify is optional for a separate static frontend.
- Razorpay: use TEST mode first. Live mode requires account verification/approval.

SETUP
1. Install Node.js 20+.
2. Copy .env.example to .env and fill in values. Never commit .env.
3. Create a Supabase project. Open SQL Editor and run supabase-schema.sql.
4. In Supabase, copy Project URL and service_role key into the backend .env. Service role is SECRET and must never be in public HTML.
5. Generate an admin password hash:
   node --input-type=module -e "import bcrypt from 'bcryptjs'; console.log(bcrypt.hashSync('CHOOSE_A_STRONG_PASSWORD', 12))"
   Replace CHOOSE_A_STRONG_PASSWORD in the command with your own password, run it locally, and put the printed hash into ADMIN_PASSWORD_HASH. Do not share the password.
6. Create a Razorpay account, use TEST API Key ID/Secret and put them in .env.
7. Install and run:
   npm install
   npm start
   Open http://localhost:3000
8. For a real deployment, create a Git repository and deploy this folder as a Node web service on Render (or another Node host). Set all .env values in the host's Environment settings. Do not upload .env.
9. Configure Razorpay webhook URL: https://YOUR-BACKEND-DOMAIN/api/payments/webhook
   Subscribe to payment.captured, payment.failed, and order.paid (where available), and set RAZORPAY_WEBHOOK_SECRET to the webhook secret.
10. Test successful payment, failed payment, duplicate webhook delivery, and admin status changes in TEST mode before switching to live keys.

ADMIN API
- POST /api/admin/login  JSON {"password":"..."} -> JWT token
- GET /api/admin/orders  Authorization: Bearer <token>
- PATCH /api/admin/orders/:id  Authorization: Bearer <token>
  JSON {"status":"processing","admin_note":"Campaign reviewed"}
  Allowed statuses: processing, completed, cancelled, refunded.
Visual dashboard: open /admin.html after deployment and sign in with the configured admin password.

IMPORTANT SECURITY / PRODUCTION TODO
- Payment signature verification is included. The webhook is separately signed.
- Before live use, add rate limiting, CSRF protections if using cookies, stronger request validation, structured logging, alerting, backups, privacy policy, terms, refund policy, and data-retention rules.
- Check webhook/database errors and reconcile payments from Razorpay dashboard. Do not rely on a client-side success callback alone.
- The sample uses a single admin password hash. For a multi-admin team, use proper account management and MFA.
- Supabase service-role key and Razorpay secret must remain server-only.
- Never ask customers for Instagram passwords or login codes.
- Packages are priced as campaign planning/promotion, not a guarantee or sale of fake followers, bot likes, or automated views. Edit prices and services only to match legitimate services you can deliver.
