-- Run this SQL in Supabase SQL Editor.
-- Keep the service-role key on the server only; never expose it to the browser.
create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  customer_name text not null,
  contact text not null,
  service text not null check (service in ('followers','likes','views')),
  package_name text not null,
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR',
  target_url text not null,
  target_username text,
  audience_notes text,
  status text not null default 'pending_payment'
    check (status in ('pending_payment','paid','processing','completed','cancelled','refunded','payment_failed')),
  payment_status text not null default 'created'
    check (payment_status in ('created','paid','failed','refunded')),
  razorpay_order_id text unique,
  razorpay_payment_id text,
  admin_note text
);

create index if not exists orders_created_at_idx on public.orders (created_at desc);
create index if not exists orders_status_idx on public.orders (status);

-- Do not add public read/write policies for orders.
-- The backend uses the Supabase service role key and checks admin JWTs.
